#!/bin/bash
echo "PM Standards Book Browser"
echo "========================"
echo ""
echo "Starting server..."
echo "Open your browser to: http://localhost:8000"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""
echo "----------------------------------------"
python3 server.py
